Welcome!!
Please read this manual before proceeding to the actual program and uninstalling packages.
As this is a very powerful tool. If not handeled very carefully it can delete some important 
apps which may result in making you to FACTORY RESET your device. So please go through this 
whole manual and then try it on your device.
WARNING: I am not responsible under any circumstances for anything happening to your device.

This software is in testing mode so its a request to all of you not to disclose it with anyone.
You can help me in making this project even better. Hoping to see great response from your side.
Thank You
--------------------------------------------------------------------------------------------
Setting up your android device for this software:
    Here we will turn on the developer options
    Go to Settings > About Phone
    Repeatedly tap on BUILD VERSION or (MIUI VERSION in XIAOMI devices). You will get a
    notification as you are now a developer.
    Find and open the developer options setting.
    Go to USB Debugging > Turn it on | Also enable the DEVELOPER OPTIONS switch.
    Your phone is ready.

Connect your device to your computer via a USB cable.

Anytime between after you connect and run the file you will get a popup in your device to allow
USB Debugging for this computer you tap on always.
On you computer find the 'debloat.exe' file and run it as Administrator.
    Right click of the file and click run as Administrator.

After you run the file you will be greated with a command line client with a 6 options.
    If you are running it for the first time then select option 1.
    You just need to enter the number of the option and press enter.
    If you are getting error message while fulfilling the requirements then restart the program
    As its requirements need a shell restart.
    
    Once all your requirements are satisfied you will see 'Done' or 'Requirements are satisfied'
    message in green color which means you are good to proceed.
    In option 2:
        All the chinese apps will be deleted. The list includes the apps banned by our Indian
        Government and I also have included apps developed by the same publisher as that of the 
        banned apps.
        If your device contains the chinese apps then it will automatically show you that you 
        have these many number of chinese apps installed and you will be notified accordingly.
        While removing these apps please dont press any key on the keyboard or else it may lead to 
        imporper execution of the command and some programs may not be uninstalled correctly causing
        further unstability. When you will proceed for uninstallation of the chinese apps it will show
	you the list of apps it is deleting one by one.
	If there are packages detected on your device then it will show the name of the package while you are removing it.

    In option 3:
        If you want to remove any specific app from your device then you can use this option.
        I will explain you with an example: In my device I have Mi Browser preinstalled by the
        manufacturer. But as we all know it is a chinese app and a spyware (in simple terms VIRUS)
        but we are unable to uninstall it. But with this option 3 you can remove such apps.
        In android the app are stored as packages. Like Whatsapp will be stored as com.whatsapp 
        YouTube will be stored as com.google.android.youtube, these packages are also referred as
        APK names. The packages will be listed as <number>	<packageName>
        Please note that:
        The processor package name is also shown in this list so please be aware of this like if you
        are having a device with processor from Qualcomm then you are likely to see packages with
        something having the word qualcomm in between. It is adviced not to remove those packages.
        You will also see your package name of settings app too. These package names are so clear
        that once you will read them you will get which app it is. 
        The steps are simple:
            You will be shown all the installed app packages following with a unique number.
            You just need to enter that number and hit ENTER for removing it.
    In option 4:
        You can get some help but it is suggesting to see this file only.
    In option 5:
        You can see some details about me and get the link for joining the discord server for
        contributing more on this project.

NOTE: After your work is over then please turn OFF the developer options from the same setting from
where you turned ON the same.

As most of the users are using chinese brands like Oppo, Vivo, Redmi, Realme, OnePlus, etc.
I have not included all the native apps of these devices, but if you want that in further versions
then join the discord server and give me suggestions and also any new feature you will like to see.
Link for server: https://discord.gg/jm8Sr5Z

---------------------------------------------------------------------------------------------------
Please dont run the file without connecting your device.

If you are unable to remove the packages then either you have not connected the device or 
you have not authorized you computer to debug your device.

If you are getting some error in installation of requirements then exit the program and then restart
as after installation of one requirement it requests a restart. After restarting you the program 
recheck the requirements your problem will be solved.

If you are getting stuck after getting the list of devices in option 2. Then wait for a while if 
you are still stuck then exit the program and then restart.

If you get a quick heal warning with something written as adb.exe then ignore that and say allow.

For further help please contact on the discord server so that others issues will also be cleared
along with yours.


Thank You 
Kanak Shilledar
Developer of Debloater